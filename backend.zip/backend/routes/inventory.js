const express = require("express");
const { inventoryType, inventorySubtype, inventoryItem } = require("../models/inventory"); 
const router = express.Router();

// Create a new inventory type
router.post("/backend/inventory/type", async (req, res) => {
  try {
    const newType = new inventoryType(req.body);
    await newType.save();
    res.status(201).json(newType);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get all inventory types
router.get("/backend/inventory/type", async (req, res) => {
  try {
    const types = await inventoryType.find().populate("subtypes");
    res.status(200).json(types);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});


// Get all inventory types
router.get("/backend/inventory/type", async (req, res) => {
  try {
    const types = await inventoryType.find().populate("subtypes");
    res.status(200).json(types);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update an inventory type
router.put("/backend/inventory/type/:id", async (req, res) => {
  try {
    const updatedType = await inventoryType.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.status(200).json(updatedType);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete an inventory type
router.delete("/backend/inventory/type/:id", async (req, res) => {
  try {
    await inventoryType.findByIdAndDelete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Create a new inventory subtype
router.post("/backend/inventory/subtype", async (req, res) => {
  try {
    const newSubtype = new inventorySubtype(req.body);
    await newSubtype.save();
    // Add the subtype ID to the parent type's subtypes array
    await inventoryType.findByIdAndUpdate(req.body.type, {
      $push: { subtypes: newSubtype._id },
    });
    res.status(201).json(newSubtype);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get all inventory subtypes
router.get("/backend/inventory/subtype", async (req, res) => {
  try {
    const subtypes = await inventorySubtype.find().populate("type");
    res.status(200).json(subtypes);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});


// Get all subtypes for a specific type
router.get("/backend/inventory/subtype/:typeId", async (req, res) => {
  try {
    const subtypes = await inventorySubtype.find({ type: req.params.typeId });
    res.status(200).json(subtypes);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update an inventory subtype
router.put("/backend/inventory/subtype/:id", async (req, res) => {
  try {
    const updatedSubtype = await inventorySubtype.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.status(200).json(updatedSubtype);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete an inventory subtype
router.delete("/backend/inventory/subtype/:id", async (req, res) => {
  try {
    await inventorySubtype.findByIdAndDelete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Create a new inventory item
router.post("/backend/inventory/item", async (req, res) => {
  try {
    const newItem = new inventoryItem(req.body);
    await newItem.save();
    // Add the item ID to the subtype's items array
    await inventorySubtype.findByIdAndUpdate(req.body.subtype, {
      $push: { items: newItem._id },
    });
    res.status(201).json(newItem);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.get("/backend/inventory/item", async (req, res) => {
  try {
    const items = await inventoryItem.find().populate("subtype");
    res.status(200).json(items);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get all items for a specific subtype
router.get("/backend/inventory/item/:subtypeId", async (req, res) => {
  try {
    const items = await inventoryItem
      .find({ subtype: req.params.subtypeId })
      .populate("subtype");
    res.status(200).json(items);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update an inventory item
router.put("/backend/inventory/item/:id", async (req, res) => {
  try {
    const updatedItem = await inventoryItem.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.status(200).json(updatedItem);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete an inventory item
router.delete("/backend/inventory/item/:id", async (req, res) => {
  try {
    await inventoryItem.findByIdAndDelete(req.params.id);
    res.status(204).send();
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Export the router
module.exports = router;
