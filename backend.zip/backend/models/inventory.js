const mongoose = require("mongoose");

// Type Schema
const inventoryTypeSchema = new mongoose.Schema({
  name: { type: String, required: true },
  subtypes: [{ type: mongoose.Schema.Types.ObjectId, ref: "inventorySubtype" }], 
});

// Subtype Schema
const inventorySubtypeSchema = new mongoose.Schema({
  name: { type: String, required: true },
  type: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "inventoryType", 
    required: true,
  },
  items: [{ type: mongoose.Schema.Types.ObjectId, ref: "inventoryItem" }], 
});

// Item Schema
const inventoryItemSchema = new mongoose.Schema({
  name: { type: String, required: true },
  code: { type: String },
  description: { type: String },
  quantity: { type: Number, required: true },
  value: { type: Number, required: true },
  location: { type: String },
  purchaseDate: { type: Date, required: true },
  condition: { type: String, required: true}, 
  subtype: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "inventorySubtype",
    required: true,
  },
  status: { type: String },
  dateAdded: { type: Date, default: Date.now },
});

const inventoryType = mongoose.model("inventoryType", inventoryTypeSchema);
const inventorySubtype = mongoose.model(
  "inventorySubtype",
  inventorySubtypeSchema
);
const inventoryItem = mongoose.model("inventoryItem", inventoryItemSchema);

module.exports = { inventoryType, inventorySubtype, inventoryItem };
